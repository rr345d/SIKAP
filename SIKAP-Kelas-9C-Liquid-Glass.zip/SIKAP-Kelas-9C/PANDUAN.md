# Panduan SIKAP Kelas 9C

## Membuka di HP Android
1. Unduh dan ekstrak ZIP ini menggunakan aplikasi pengelola file.
2. Buka `index.html` melalui browser jika pengelola file menyediakan opsi tersebut.
3. Jika browser tidak bisa membuka file lokal, unggah isi proyek ke repositori GitHub baru, lalu aktifkan GitHub Pages melalui Settings → Pages.
4. Buka URL Pages yang diberikan GitHub.

## Yang bisa dicoba pada DEMO
- Navigasi dashboard dan halaman data.
- Tambah/edit/hapus data contoh siswa.
- Catat absensi dan mencegah duplikasi siswa/tanggal pada antarmuka.
- Tambah catatan pembinaan, jadwal piket, evaluasi ketertiban, dan pengumuman.
- Pilih foto kecil untuk galeri lokal.
- Ekspor beberapa data menjadi CSV.
- Jam real-time WIB.

## Batasan
Data disimpan hanya pada browser perangkat ini melalui localStorage. Itu bukan database online, tidak sinkron antarpengguna, dan tidak aman untuk administrasi kelas. Login dan hak akses server belum aktif. Fitur galeri DEMO menyimpan gambar di browser dan dapat memenuhi kuota penyimpanan.

## Tahap berikutnya untuk versi online
1. Buat proyek Supabase.
2. Jalankan `supabase_schema.sql` di SQL Editor setelah meninjau skema dan kebijakannya.
3. Aktifkan email/password Auth dan buat alur akun yang aman.
4. Hubungkan frontend menggunakan URL proyek dan anon/publishable key saja.
5. Terapkan serta uji RLS untuk setiap tabel dan Storage bucket. Jangan pernah gunakan service-role key di frontend.
6. Buat admin pertama melalui dashboard Supabase/Auth dan penetapan role melalui jalur tepercaya, bukan formulir publik.
7. Uji dengan akun admin dan siswa terpisah sebelum memakai data asli.

## Catatan privasi
Minta izin sekolah/orang tua sesuai kebijakan sekolah sebelum mengunggah foto siswa. Catatan pembinaan harus hanya terlihat oleh pihak yang memiliki kewenangan sah.


## Tampilan Liquid Glass
Versi ini menggunakan wallpaper aurora pastel dan elemen bergaya kaca transparan. Efek blur paling terlihat pada browser yang mendukung `backdrop-filter`; jika tidak didukung, layout tetap dapat digunakan dengan latar transparan.
