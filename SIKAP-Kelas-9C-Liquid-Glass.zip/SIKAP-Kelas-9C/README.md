# SIKAP Kelas 9C — Versi Awal DEMO

Identitas aplikasi: **SIKAP · Kelas 9C · SMPN 3 Soreang**

## Isi paket
- `index.html` — prototipe responsif HTML/CSS/JavaScript.
- `supabase_schema.sql` — rancangan awal database dan kebijakan RLS (belum diterapkan).
- `PANDUAN.md` — cara membuka demo dan langkah menuju versi online.

## Status penting
Versi HTML ini adalah DEMO lokal. Beberapa interaksi berfungsi, termasuk navigasi, jam WIB, CRUD data contoh, pencarian, ekspor CSV, dan galeri lokal. Data disimpan di `localStorage` perangkat/browser ini, bukan database terpusat. Tidak ada login nyata, tidak ada perlindungan server, dan role admin/siswa belum diterapkan. **Jangan masukkan data siswa asli atau catatan pelanggaran sungguhan.**

Untuk aplikasi produksi, terapkan Supabase Auth, schema SQL yang ditinjau, RLS, Storage policies, validasi server, dan alur undangan akun. Jangan menyimpan service-role key di frontend.


Pembaruan tampilan: versi Liquid Glass dengan wallpaper aurora pastel, panel kaca transparan, efek blur, dan animasi latar yang halus. Wallpaper dibuat dengan CSS sehingga tidak membutuhkan koneksi internet.
