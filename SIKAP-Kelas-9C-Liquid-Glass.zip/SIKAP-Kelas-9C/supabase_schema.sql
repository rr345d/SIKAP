-- SIKAP Kelas 9C: schema scaffold for Supabase/PostgreSQL
-- Review before production. This schema is not connected to index.html demo.
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin','student');
create type public.attendance_status as enum ('hadir','sakit','izin','alpa');

create table public.classes (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  school_name text not null default 'SMPN 3 Soreang',
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role public.app_role not null default 'student',
  class_id uuid references public.classes(id),
  student_id uuid,
  created_at timestamptz not null default now()
);

create table public.students (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  profile_id uuid unique references public.profiles(id) on delete set null,
  full_name text not null,
  student_number text,
  is_active boolean not null default true,
  photo_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles add constraint profiles_student_id_fkey
  foreign key (student_id) references public.students(id) on delete set null deferrable initially deferred;

create table public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id),
  attendance_date date not null,
  status public.attendance_status not null,
  note text,
  recorded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(student_id, attendance_date)
);

create table public.violations (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  student_id uuid not null references public.students(id),
  incident_date date not null,
  category text not null,
  objective_description text not null,
  follow_up text,
  visibility text not null default 'staff' check (visibility in ('staff','student_self')),
  recorded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.piket_schedules (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  weekday smallint not null check (weekday between 1 and 6),
  student_id uuid not null references public.students(id),
  tasks text[] not null default '{}',
  starts_on date,
  ends_on date,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.class_evaluations (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  evaluation_date date not null,
  indicators jsonb not null default '{}'::jsonb,
  notes text,
  follow_up text,
  recorded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  title text not null,
  body text not null,
  category text not null default 'Informasi',
  is_important boolean not null default false,
  published_at timestamptz,
  expires_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.class_photos (
  id uuid primary key default gen_random_uuid(),
  class_id uuid not null references public.classes(id),
  title text not null,
  caption text,
  photo_path text not null,
  photo_date date,
  is_cover boolean not null default false,
  uploaded_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  class_id uuid references public.classes(id),
  actor_id uuid references public.profiles(id),
  table_name text not null,
  record_id text not null,
  action text not null check (action in ('INSERT','UPDATE','DELETE')),
  changed_at timestamptz not null default now(),
  summary jsonb not null default '{}'::jsonb
);

create index attendance_date_idx on public.attendance(attendance_date);
create index violations_class_date_idx on public.violations(class_id, incident_date);
create index announcements_class_published_idx on public.announcements(class_id, published_at desc);

-- Security helper functions. SECURITY DEFINER avoids recursive RLS lookups; pin search_path.
create or replace function public.current_role()
returns public.app_role language sql stable security definer
set search_path = public
as $$ select role from public.profiles where id = auth.uid() $$;

create or replace function public.current_class_id()
returns uuid language sql stable security definer
set search_path = public
as $$ select class_id from public.profiles where id = auth.uid() $$;

create or replace function public.is_class_admin(target_class uuid)
returns boolean language sql stable security definer
set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin' and p.class_id = target_class) $$;

alter table public.classes enable row level security;
alter table public.profiles enable row level security;
alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.violations enable row level security;
alter table public.piket_schedules enable row level security;
alter table public.class_evaluations enable row level security;
alter table public.announcements enable row level security;
alter table public.class_photos enable row level security;
alter table public.audit_log enable row level security;

-- Read policies: class members may see class-level content; sensitive violations are restricted.
create policy "members read own class" on public.classes for select
using (id = public.current_class_id());

create policy "read profiles in same class" on public.profiles for select
using (class_id = public.current_class_id() and (id = auth.uid() or public.current_role() = 'admin'));

create policy "admin manage profiles same class" on public.profiles for all
using (public.is_class_admin(class_id)) with check (public.is_class_admin(class_id));

create policy "members read students in class" on public.students for select
using (class_id = public.current_class_id());

create policy "admin manage students" on public.students for all
using (public.is_class_admin(class_id)) with check (public.is_class_admin(class_id));

create policy "members read attendance in class" on public.attendance for select
using (exists(select 1 from public.students s where s.id = student_id and s.class_id = public.current_class_id())
  and (public.current_role() = 'admin' or exists(select 1 from public.students s join public.profiles p on p.id=s.profile_id where s.id=student_id and p.id=auth.uid())));

create policy "admin manage attendance" on public.attendance for all
using (exists(select 1 from public.students s where s.id = student_id and public.is_class_admin(s.class_id)))
with check (recorded_by = auth.uid() and exists(select 1 from public.students s where s.id = student_id and public.is_class_admin(s.class_id)));

create policy "admin read violations" on public.violations for select
using (public.is_class_admin(class_id));
create policy "student self read allowed violations" on public.violations for select
using (visibility = 'student_self' and exists(select 1 from public.profiles p where p.id=auth.uid() and p.student_id=violations.student_id));
create policy "admin manage violations" on public.violations for all
using (public.is_class_admin(class_id))
with check (recorded_by = auth.uid() and public.is_class_admin(class_id));

create policy "members read piket" on public.piket_schedules for select
using (class_id = public.current_class_id());
create policy "admin manage piket" on public.piket_schedules for all
using (public.is_class_admin(class_id)) with check (created_by = auth.uid() and public.is_class_admin(class_id));

create policy "members read class evaluations" on public.class_evaluations for select
using (class_id = public.current_class_id());
create policy "admin manage evaluations" on public.class_evaluations for all
using (public.is_class_admin(class_id)) with check (recorded_by = auth.uid() and public.is_class_admin(class_id));

create policy "members read published announcements" on public.announcements for select
using (class_id = public.current_class_id() and published_at is not null and published_at <= now() and (expires_at is null or expires_at > now()));
create policy "admin manage announcements" on public.announcements for all
using (public.is_class_admin(class_id)) with check (created_by = auth.uid() and public.is_class_admin(class_id));

create policy "members read class photos" on public.class_photos for select
using (class_id = public.current_class_id());
create policy "admin manage class photos" on public.class_photos for all
using (public.is_class_admin(class_id)) with check (uploaded_by = auth.uid() and public.is_class_admin(class_id));

create policy "admin read audit log" on public.audit_log for select
using (class_id is not null and public.is_class_admin(class_id));

-- IMPORTANT:
-- 1. This is a starter schema, not a complete production security review.
-- 2. Create the first admin through a trusted server/admin workflow. Never let public users
--    self-assign role='admin'. Do not expose service_role key in a browser.
-- 3. Add database triggers for updated_at and audit_log, and storage.objects policies for a
--    private class-photos bucket before production.
-- 4. Review profiles update privileges; prefer narrow column permissions or trusted RPCs so
--    users cannot edit their own role/class_id.
